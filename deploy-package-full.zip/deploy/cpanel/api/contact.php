<?php
// Proxy to main contact handler
require_once __DIR__ . '/../contact_handler.php';
?>
