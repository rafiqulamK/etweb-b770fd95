<?php
// db_config.php (deployment-safe template)
// This file used to contain embedded credentials. To avoid shipping secrets,
// it now returns an empty array. Set environment variables instead:
// DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS or create a private db_config.php locally.

return [];
